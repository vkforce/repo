__author__ = 'Forcepoint'

from flask import Flask
from qpylib import qpylib
import os

# Flask application factory.
def create_app():
    # Create a Flask instance.
    qflask = Flask(__name__)

    # Retrieve QRadar app id.
    qradar_app_id = qpylib.get_app_id()

    # Create unique session cookie name for this app.
    qflask.config['SESSION_COOKIE_NAME'] = 'session_{0}'.format(qradar_app_id)

    # Hide server details in endpoint responses.
    # pylint: disable=unused-variable
    @qflask.after_request
    def obscure_server_header(resp):
        resp.headers['Server'] = 'QRadar App {0}'.format(qradar_app_id)
        return resp

    # Register q_url_for function for use with Jinja2 templates.
    qflask.add_template_global(qpylib.q_url_for, 'q_url_for')

    # Initialize logging.
    qpylib.create_log()
    if 'QRADAR_APP_ID' not in os.environ:
        os.environ['QRADAR_APP_ID'] = '1111'

    if 'QRADAR_APP_UUID' not in os.environ:
        os.environ['QRADAR_APP_UUID'] = 'aa9f9152-3d61-424a-9e8d-7af427274e00'
        
    if 'FLASK_APP' not in os.environ:
        os.environ['FLASK_APP'] = 'app'

    if 'QRADAR_CONSOLE_IP' not in os.environ:
        # To prevent an exception (new QRadar behavior) when the var is not set in dev container
        os.environ['QRADAR_CONSOLE_IP'] = '127.0.0.1'
        
    # To enable app health checking, the QRadar App Framework
    # requires every Flask app to define a /debug endpoint.
    # The endpoint function should contain a trivial implementation
    # that returns a simple confirmation response message.
    @qflask.route('/debug')
    def debug():
        return 'Pong!'

    # Import additional endpoints.
    # For more information see:
    #   https://flask.palletsprojects.com/en/1.1.x/tutorial/views
    from . import views
    qflask.register_blueprint(views.viewsbp)

    return qflask
