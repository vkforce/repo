from flask import Blueprint
import threading
import json
from app.logger import logger
from qpylib import qpylib
# import socket
import random
import time
# import datetime
thread_lock = threading.Lock()
viewsbp = Blueprint('viewsbp', __name__, url_prefix='/')
thread = None
# SYSLOG_HEADER_DATEFORMAT = '%b %d %H:%M:%S'
# SYSLOG_HEADER = '%s personallog :%s'
data = {"protocol": "https", "customlocation": [], "requestport": "443", "requestmethod": "GET", "usergroup": [], "bgcategories": ["BG:Content and Publishing", "BG:Education", "BG:Internet Services", "BG:Media and Entertainment", "BG:Software"], "size": 2485, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "15.235.7.123", "webreputation": 81.0, "long": -79.3716, "application": "MSN", "requestdomain": "assets.msn.com", "setransactionid": "0e657353-39b8-4c7e-8a55-868375bc3aee", "arguments": "market=en-GB&source=appxmanifest&tenant=amp&vertical=sports", "indexedtime": "", "email":"user1@fpcert03.com", "bgcloudscore": 8.0, "firstname": "", "lastname": "", "devicehostname": "701fd52e923c", "regioncode": "", "policyid": "2874646", "lat": 43.6319, "uploadedbytes": 187, "webcategories": ["WR:Internet Portals"], "countrycode": "CA", "referrer": "", "url": "assets.msn.com/service/msn/livetile/singletile?market=en-GB&source=appxmanifest&tenant=amp&vertical=sports", "country": "Canada", "region": "", "uri": "/service/msn/livetile/singletile", "customcategories": [], "time": "2024-01-24 13:02:54", "action": "blocked", "useragent": "Microsoft-WNS/10.0", "webcategoryclass": ["Social Media/Internet Communication"], "logtype": "raw-logs"}
data1 = {"protocol": "https", "customlocation": [], "requestport": "443", "requestmethod": "GET", "usergroup": [], "bgcategories": ["BG:Content and Publishing", "BG:Education", "BG:Internet Services", "BG:Media and Entertainment", "BG:Software"], "size": 2485, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "182.2.88.185", "webreputation": 81.0, "long": -79.3716, "application": "MSN", "requestdomain": "assets.msn.com", "setransactionid": "0e657353-39b8-4c7e-8a55-868375bc3aee", "arguments": "market=en-GB&source=appxmanifest&tenant=amp&vertical=sports", "indexedtime": "", "email":"admin@fpcert01com", "bgcloudscore": 8.0, "firstname": "", "lastname": "", "devicehostname": "701fd52e923c", "regioncode": "", "policyid": "2874646", "lat": 43.6319, "uploadedbytes": 187, "webcategories": ["WR:Internet Portals"], "countrycode": "CA", "referrer": "", "url": "https://example.com/base/boundary.php", "country": "Canada", "region": "", "uri": "/service/msn/livetile/singletile", "customcategories": [], "time": "2024-01-24 13:02:54", "action": "blocked", "useragent": "Microsoft-WNS/10.0", "webcategoryclass": ["Social Media/Internet Communication"], "logtype": "raw-logs"}
data2 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "HEAD", "usergroup": [], "bgcategories": ["BG:Business Applications", "BG:Cloud Computing", "BG:Collaboration", "BG:Consumer Electronics", "BG:Hardware", "BG:Platforms", "BG:Software"], "size": 351, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "15.235.7.123", "webreputation": 80.0, "long": -79.3716, "application": "Microsoft Windows Update", "requestdomain": "au.download.windowsupdate.com", "setransactionid": "d814cb58-9bf4-49d9-9df7-524ddd31ebd9", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "usre2@gamil.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "", "policyid": "2867019", "lat": 43.6319, "uploadedbytes": 248, "webcategories": ["WR:Computer and Internet Info"], "countrycode": "CA", "referrer": "", "url": "c/msdownload/update/software/defu/2024/01/am_engine_e39a50e65fbc4ab3544d0f42c0e37432f5e5af22.exe", "country": "Canada", "region": "", "uri": "/c/msdownload/update/software/defu/2024/01/am_engine_e39a50e65fbc4ab3544d0f42c0e37432f5e5af22.exe", "customcategories": [], "time": "2024-02-01 18:23:41", "action": "blocked", "useragent": "Microsoft BITS/7.8", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}
data3 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "GET", "usergroup": [], "bgcategories": ["BG:Business Applications", "BG:Cloud Computing", "BG:Collaboration"], "size": 7580, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "61.222.238.112", "webreputation": 92.0, "long": -73.5848, "application": "Microsoft Windows Update", "requestdomain": "download.windowsupdate.com", "setransactionid": "8bc7374a-7c8e-4021-b75f-7af3c6907b75", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "mainuser@fpcert03.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "QC", "policyid": "2867019", "lat": 45.4995, "uploadedbytes": 249, "webcategories": ["WR:Computer and Internet Info"], "countrycode": "CA", "referrer": "", "url": "jnder.com/c/msdownload/update/others", "country": "Canada", "region": "Quebec", "uri": "/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "customcategories": [], "time": "2024-02-01 18:24:42", "action": "blocked", "useragent": "Windows-Update-Agent/10.0.10011.16384 Client-Protocol/1.40", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}
data4 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "HEAD", "usergroup": [], "bgcategories": ["BG:Business Applications", "BG:Hardware", "BG:Platforms", "BG:Software"], "size": 7580, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "51.111.238.112", "webreputation": 92.0, "long": -73.5848, "application": "Microsoft Windows Update", "requestdomain": "download.windowsupdate.com", "setransactionid": "8bc7374a-7c8e-4021-b75f-7af3c6907b75", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "forcepoint@fpcert03.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "QC", "policyid": "2867019", "lat": 45.4995, "uploadedbytes": 249, "webcategories": ["users"], "countrycode": "CA", "referrer": "", "url": "outing.com/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "country": "Canada", "region": "Quebec", "uri": "/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "customcategories": [], "time": "2024-02-01 18:24:42", "action": "blocked", "useragent": "Windows-Update-Agent/10.0.10011.16384 Client-Protocol/1.40", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}
data5 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "GET", "usergroup": [], "bgcategories": ["BG:Business Applications", "BG:Cloud Computing", "BG:Collaboration", "BG:Consumer Electronics", "BG:Hardware", "BG:Platforms", "BG:Software"], "size": 7580, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "51.222.238.112", "webreputation": 92.0, "long": -73.5848, "application": "Microsoft Windows Update", "requestdomain": "download.windowsupdate.com", "setransactionid": "8bc7374a-7c8e-4021-b75f-7af3c6907b75", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "user5@fpcert03.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "QC", "policyid": "2867019", "lat": 45.4995, "uploadedbytes": 249, "webcategories": ["WR:Computer and Internet Info"], "countrycode": "CA", "referrer": "", "url": "download.windowsupdate.com/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "country": "Canada", "region": "Quebec", "uri": "/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "customcategories": [], "time": "2024-02-01 18:24:42", "action": "allow", "useragent": "Windows-Update-Agent/10.0.10011.16384 Client-Protocol/1.40", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}
data6 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "HEAD", "usergroup": [], "bgcategories": ["BG:Business Applications", "BG:Cloud Computing", "BG:Hardware", "BG:Platforms", "BG:Software"], "size": 7580, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "51.166.238.112", "webreputation": 92.0, "long": -73.5848, "application": "Microsoft Windows Update", "requestdomain": "download.windowsupdate.com", "setransactionid": "8bc7374a-7c8e-4021-b75f-7af3c6907b75", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "yufer@fpcert03.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "QC", "policyid": "2867019", "lat": 45.4995, "uploadedbytes": 249, "webcategories": ["justify", "main"], "countrycode": "CA", "referrer": "", "url": "tusf.com/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "country": "Canada", "region": "Quebec", "uri": "/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "customcategories": [], "time": "2024-02-01 18:24:42", "action": "blocked", "useragent": "Windows-Update-Agent/10.0.10011.16384 Client-Protocol/1.40", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}
data7 = {"protocol": "http", "customlocation": [], "requestport": "80", "requestmethod": "GET", "usergroup": [], "bgcategories": ["BG:Consumer Electronics", "BG:Hardware", "BG:Platforms", "BG:Software"], "size": 7580, "city": "", "deviceguid": "", "destinationip": "", "ipaddress": "51.125.238.112", "webreputation": 92.0, "long": -73.5848, "application": "Microsoft Windows Update", "requestdomain": "download.windowsupdate.com", "setransactionid": "8bc7374a-7c8e-4021-b75f-7af3c6907b75", "arguments": "", "indexedtime": "2024-02-01 18:28:02+00:00", "email": "jiinher@fpcert03.com", "bgcloudscore": 10.0, "firstname": "", "lastname": "", "devicehostname": "23e27e68bbe2", "regioncode": "QC", "policyid": "2867019", "lat": 45.4995, "uploadedbytes": 249, "webcategories": ["WR:Computer and Internet Info", "Some other cahra"], "countrycode": "CA", "referrer": "", "url": "userface.com/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "country": "Canada", "region": "Quebec", "uri": "/c/msdownload/update/others/2024/02/40611201_ad1c4ab5c0c844958e6670eb208f0631095f644e.cab", "customcategories": [], "time": "2024-02-01 18:24:42", "action": "blocked", "useragent": "Windows-Update-Agent/10.0.10011.16384 Client-Protocol/1.40", "webcategoryclass": ["Business/Government/Services"], "log_type": "raw-logs"}


# syslog = SYSLOG_HEADER % (datetime.datetime.now().strftime(SYSLOG_HEADER_DATEFORMAT), json.dumps(data))
json_data = json.dumps(data)
json_data1 = json.dumps(data1)
json_data2 = json.dumps(data2)
json_data3 = json.dumps(data3)
json_data4 = json.dumps(data4)
json_data5 = json.dumps(data5)
json_data6 = json.dumps(data6)
json_data7 = json.dumps(data7)
# import logging
# from logging.handlers import SysLogHandler
# # Configure logging to send to QRadar syslog
# logging.basicConfig(level=logging.INFO, handlers=[SysLogHandler(address=(qpylib.get_console_address(), 514), socktype=socket.SOCK_STREAM)])
# # Create a logger
# logger = logging.getLogger(__name__)
# logger.info("This is my message")

def background_task():
    counter = 0
    while True:
        with thread_lock:  # Acquire the lock before proceeding
            # qradar_logger = logging.getLogger('qradar')
            # qradar_logger.addHandler(logging.handlers.SysLogHandler(
            #     address=('localhost', 514)))
            # qradar_logger.info(syslog)
            # logger.log(syslog, "INFO")
            # logger.log(json_data)
            random_number = random.randint(1, 4)
            if random_number==0:
                qpylib.log(json_data)
            elif random_number == 1:
                qpylib.log(json_data1)
            elif random_number == 2:
                qpylib.log(json_data2)
            else:
                qpylib.log(json_data3)
            qpylib.log(json_data4)
            qpylib.log(json_data5)
            qpylib.log(json_data6)
            qpylib.log(json_data7)
            # qpylib.log("called the main route", "INFO")
            time.sleep(10)



@viewsbp.route('/')
@viewsbp.route('/index')
def index():
    qpylib.log("called the main route", "INFO")
    # with thread_lock:
    #     global thread  # Declare thread as global within the function
    #     if thread is not None and thread.is_alive():  # Check if thread exists and is running
    #         thread.join()
    #     thread = threading.Thread(target=background_task)
    #     thread.start()
    external_api_url = "https://google.com/"
    response = qpylib.REST("get", external_api_url)
    qpylib.log(response.status_code)
    # if response.status_code == 200:
    #     data = response.json()
    #     print(f"API response: {data}")
    # else:
    #     print(f"Error calling API: {response.status_code} - {response.text}")

    return "Hello World!"
