import logging
from qpylib import qpylib
from logging.handlers import SysLogHandler
from logging import Formatter
import socket
class QLogger:
    def __init__(self, logger_name):
        self.logger = logging.getLogger(logger_name)
        self.add_log_handler()

    @staticmethod
    def get_console_address():
        return qpylib.get_console_address()

    def add_log_handler(self):
        syslog_handler = SysLogHandler(address=(self.get_console_address(), 514), socktype=socket.SOCK_STREAM)
        syslog_handler.setFormatter(Formatter('%(asctime)s %(module)s.%(funcName)s: %(message)s'))
        self.logger.addHandler(syslog_handler)

    def log(self, message, level='info'):
        if level == 'info':
            self.logger.info(message)
        elif level == 'error':
            self.logger.error(message)
        elif level == 'warning':
            self.logger.warning(message)


logger = QLogger("com.qradar.ibm")
